#include <stdlib.h>
#include <stdio.h>

int main()
{
	printf("Hello World\n");
	exit(EXIT_SUCCESS);
}
